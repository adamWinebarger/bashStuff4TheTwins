require 'spec_helper'

fullColumn = 'column found to be full up. Please choose another'
invalidColumn = 'Invalid column selected'

describe 'C4 standard board size' do
    it 'detects P1 winning horizontally in row 0' do
        # Notice that the game should end before the last 'q' input is consumed
        result = test_c4('aabbccdq')
        expect(result).to declare_win_for 1
    end

    it 'quits before declaring a winner in column 0' do
        result = test_c4('abababq')
        expect(result).to be_abandoned
    end
end


##We have nothing in the specs about i being a valid character but this test method looks like

#describe 'Connect 4 alternate' do
    #it 'detects player 2 winning horizontally on a big board' do
        #result = test_c4('iaabbccddeeffgq', 3, 9, 7)
        #expect(result).to declare_win_for 2
    #end

describe 'Connect 4 alternate 2' do
    it 'detects player 2 winning horizontally on a big board' do
        result = test_c4('iaabbccddeeffgq', 3, 9, 7)
        expect(result).to declare_win_for 2
    end

    it 'quits before declaring a winner in column 0' do
        result = test_c4('iaabbccddeeffq', 3, 9, 7) #Had to re-write this one a bit as we have a catchment that prevents the win condition from being bigger than either board parameter.
        expect(result).to be_abandoned
    end
end

=begin

Basic victory conditions. So here we're going to want to test wins vertically, horizontally, and then above right to below left,
and below-left to above right. In addition to testing them normally (middle of the board), it would probably be sensible to test
each of the victory conditions at each of the bounds (left, right, top, bottom) and maybe the corners. I've black-box tested most
of these already but it might be nice to have some automation in there for the rest of them

=end

#horizontally along the bottom
describe 'Player wins horizontally along the bottom boundary' do
    it 'detects player 1 winning horizontally in the bottom row; ensures no boundary issues' do
        result = test_c4('ddeeffgghhiiq',10, 10, 5)
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning horizontally, along the bottom, from the left corner' do
        result = test_c4('gaabbccddq')
        expect(result).to declare_win_for 2
    end

    it 'detects player 2 winning horizontally, along the bottom, from the right corner' do
        result = test_c4('aggffeeddq')
        expect(result).to declare_win_for 2
    end
end

#horizontally in the body of the board
describe 'Player wins horizontally from middle of the board' do
    it 'detects player 1 winning horizontally from the middle of the board (not touching the bounadaries)' do
        result = test_c4('abcdefgabcdefgbbccddeeq', 7, 7, 4)
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning horizontally, with the leftmost piece touching the left boundary' do
        result = test_c4('abcdefghijkabcdefghijkabcdefghijkaabbccddeeq', 11, 11, 5)
        expect(result).to declare_win_for 2
    end

    # number 10
    it 'detects player 1 winning horizontally with the rightmost piece touching the right boundary' do
        result = test_c4('abcdefghijklmnoabcdefghijklmnooonnmmllkkjjq', 15, 15, 6) #last j and q won't be read
        expect(result).to declare_win_for 1
    end
end

#horizontally along the top
describe 'Player wins horizontally along the top boundary' do
    it 'detects player 1 winning along the top boundary, not touching either corner' do
        result = test_c4('bcdebcdebcdeedcbehdhchbq', 5, 8, 4)
        expect(result).to declare_win_for 1
    end

    it 'detects player 1 wins along the top boundary, from the left corner' do
        result = test_c4('abcdabcdabcddcbaahbhchdq', 5, 8, 4)
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning along the top boundary, from the right corner' do
        result = test_c4('efghefghefghhgfeahagafbeq', 5, 8, 4)
        expect(result).to declare_win_for 2
    end
end

##Alright now. Time for vertical tests

describe 'Player wins vertically along the bottom boundary' do
    it 'detects player 1 winning vertically, in the leftmost column, with the bottom-most piece in the bottom row' do
        result = test_c4('ababababq')   #that last b shouldn't actually do anything, but I figured why not put it there?
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning vertically with the bottom most piece in the bottom row' do
        result = test_c4('acdcdcdcdq')
        expect(result).to declare_win_for 2
    end

    it 'detects player 2 winning vertically in the rightmost column, with the lowest piece in the bottom row' do
        result = test_c4('agfgfgfgfq')
        expect(result).to declare_win_for 2
    end
end

describe 'Player wins vertically in the body of the board' do
    it 'detects player 2 winning vertically along the left boundary' do
        result = test_c4('abcdefgababababq') #Again, more garbage-noise inputs at the end to make sure it doesn't affect anything
        expect(result).to declare_win_for 2
    end

    it 'detects player 1 winning vertically, while not touching any boundaries' do
        result = test_c4('ghghghhghghghghghghghghghq', 16, 16, 10)
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning vertically along the right boundary' do
        result = test_c4('abcdefggfgfgfgq')
        expect(result).to declare_win_for 2
    end
end

describe 'Player wins vertically from the top' do
    it 'detects player 2 winning vertically, along the left bounadary, with the topmost piece being in the top row' do
        result = test_c4('abcddabababq', 4, 4, 3) #Also tests our minimum size board, so that's cool
        expect(result).to declare_win_for 2
    end

    it 'detects player 1 winning vertically in a non-boundary column with the topmost piece on top' do
        result = test_c4('dfdfdffdfdfdfdfq', 8, 8, 5)
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning vertically along the right boundary with the topmost piece on top' do
        result = test_c4('poapopopopopopopopopopopopopopopoq', 16, 16, 15)
        expect(result).to declare_win_for 2
    end
end

##Diagonals now... fml

#Diagonals, upper-left to lower-right
describe 'Player wins diagonally from upper-left to lower right' do
    it 'detects player 1 winning diagonally, from upper-left, to lower-right; with the lower-right-most piece in the lower right corner' do
        result = test_c4('gfffeeeddddq')
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning diagonal (ul2lr) with the lower-rightmost piece on the lower boundary' do
        result = test_c4('gfeeedddccccq')
        expect(result).to declare_win_for 2
    end

    it 'detects player 2 winning diagonal (ul2lr) with the lower-rightmost piece in the right column' do
        result = test_c4('gggfffeeeeddddedq')
        expect(result).to declare_win_for 2
    end

    it 'detects player 1 winning diagonal (ul2lr) with the lower-right piece on the lower bounday; upper-left in the leftmost column' do
        result = test_c4('dcccbbbaaaaq')
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning diagonal (ul2lr) with the upper-leftmost piece touching the left boundary' do
        result = test_c4('dddcccbbbbaaaabaq')
        expect(result).to declare_win_for 2
    end

    it 'detects player 2 winning diagonal (ul2lr) with no pieces touching any bounadaries' do
        result = test_c4('fffeeeddddccccdcq')
        expect(result).to declare_win_for 2
    end

    it 'detects player 1 winning diagonally (ul2lr) with the upper-leftmost piece in the upper-left corner' do
        result = test_c4('abcdefgabcdefgdcccbbbaaaaq')
        expect(result).to declare_win_for 1
    end

    it 'detects player 1 winning diagonally (ul2lr) with the upper-leftmost piece touching the top boundary' do
        result = test_c4('fffeeeeddddedccccccq')
        expect(result).to declare_win_for 1
    end
end

#Now we can move onto diagonals, lower-left to upper-right
describe 'Player wins diagonally from lower-left to upper right' do

    it 'detects player 1 winning diagonally (ll2ur) with the lower-leftmost piece in the bottom-left corner' do
        result = test_c4('abbbcccdddddeeeeefffffffggggggghhhhhhhhhiiiiiiiiijjjjjjjjjjjkkkkkkkkkkklllllllllllllmmmmmmmmmmmmmnnnnnnnnnnnnnnq', 15, 15, 14)
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning diagonally (ll2ur) with the lower-leftmost piece on the bottom boundarary' do
        result = test_c4('abcccdddeeeeq')
        expect(result).to declare_win_for 2
    end

    it 'detects player 2 winning diagonally (ll2ur) with the lower-leftmost piece in the leftmost column' do
        result = test_c4('aabbabcccccdddddq')
        expect(result).to declare_win_for 2
    end

    it 'detects player 1 winning diagonally (ll2ur) with no pieces touching any bounadaries' do
        result = test_c4('abcdefghijabcdefghijdeeefffggggq', 10, 10, 5)
        expect(result).to declare_win_for 1
    end

    it 'detects player 1 winning diagonally (ll2ur) with the upper-rightmost piece in the rightmost column' do
        result = test_c4('bcccdddeeeeq', 5, 5, 4)
        expect(result).to declare_win_for 1
    end

    it 'detects player 1 winning diagonally (ll2ur) with uppper-rightmost piece in the upper-right corner' do
        result = test_c4('eeeeedddddccccbcbq', 5, 5, 4)
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning diagonally (ll2ur) with upper-rightmost piece touching the upper boundarary' do
        result = test_c4('eeeeeefdddddccccbbfb')
        expect(result).to declare_win_for 2
    end

end

=begin

These will be boundarary integrity checks. Basically making sure that if you have win-1 on one bounadary and one extra
on the other that it won't trigger a the win.

=end

describe 'Tests to make sure player does not trigger win based on boundary clip' do

    it 'detects no win has been triggered from 3 in a row on the left side, 3 in a row on the right; bottom boundary' do
        result = test_c4('aabbccggffeeq')
        expect(result).to be_abandoned
    end

    it 'detects no win has been triggered with 7, on the left, 8 on the right' do
        result = test_c4('aabbccddeeffgghhjjkkllmmnnooppq', 16, 16, 15)
        expect(result).to be_abandoned
    end

    it 'detects no win has been triggered vertically on clip' do
        result = test_c4('abababbabaabq')
        expect(result).to be_abandoned
    end

    it 'detects no win has been triggered horizontally if there are 4 in a row by index but on or more pieces are separated by a boundary' do
        result = test_c4('ggffeecaq')
        expect(result).to be_abandoned
    end

    it 'detects that a clip doesn\'t cause a diagonal victory' do
        result = test_c4('gaaaaaabbbbcbccecffq')
        expect(result).to be_abandoned
    end

end

##Game ends in draw
describe 'Instances where the game would end in a draw' do
   it 'detects draw big board' do
        result = test_c4('abcdefghabcdefghabcdefghabcdefghabcdefghabcdefghhgfedcbahgfedcba', 8, 8, 7)
        #expect(result).to declare_win_for -1
        expect(result).to be_abandoned
    end
end

=begin

any invalid input parameters should lead to a game starting where the board is 6x7 with a 4 win condition.

With this in mind, we can test whether the default parameters took by throwing in invalid parameters and then playing out
the game to see if 4 in a row really took

=end

describe 'Testing the effects of invalid parameters on our board/game' do

    it 'detects invalid input in the row parameter' do
        result = test_c4('aabbccdq', 'a', 8, 5) #notice all other parameters are valid
        expect(result).to declare_win_for 1 #the letter combo set up should lead to a win for 1 if the default board has been set up
    end

    it 'checks that only 7 columns were provided with invalid row parameter' do
        result = test_c4('hq', 'a', 8, 4)
        expect(result).to invalid_input invalidColumn
    end

    it 'checks that only 6 rows are present when invalid row parameter proveided' do
        result = test_c4('aaaaaaaq', 'a', 8, 4)
        expect(result).to invalid_input fullColumn
    end

    it 'checks invalid input on column parameter' do
        result = test_c4('aabbccdq', 9, 'b', 6)
        expect(result).to declare_win_for 1
    end

    it 'checks only 7 columns on invalid column parameter' do
        result = test_c4('hq', 9, 'b', 6)
        expect(result).to invalid_input invalidColumn
    end

    it 'checks that only 6 rows are present when invalid column parameter is present' do
        result = test_c4('aaaaaaaq', 9, 'b', 6)
        expect(result).to invalid_input fullColumn
    end

    it 'checks that default board loaded on bad win parameter' do
        result = test_c4('aabbccdq', 12, 9, 'm')
        expect(result).to declare_win_for 1
    end

    it 'check  that only 7 columns on invalid win parameter' do
        result = test_c4('hq', 12, 9, 'm')
        expect(result).to invalid_input invalidColumn
    end

    it 'checks only 6 rows when bad win parameter input' do
        result = test_c4('aaaaaaaq', 12, 9, 'm')
        expect(result).to invalid_input fullColumn
    end

end

describe 'Testing the effect of null parameters on the board load... should be the same as invalid' do

    it 'detects null input in the row parameter' do
        result = test_c4('aabbccdq', nil, 8, 5) #notice all other parameters are valid
        expect(result).to declare_win_for 1 #the letter combo set up should lead to a win for 1 if the default board has been set up
    end

    it 'checks that only 7 columns were provided with null row parameter' do
        result = test_c4('hq', nil, 8, 4)
        expect(result).to invalid_input invalidColumn
    end

    it 'checks that only 6 rows are present when null row parameter proveided' do
        result = test_c4('aaaaaaaq', nil, 8, 4)
        expect(result).to invalid_input fullColumn
    end

    it 'checks null input on column parameter' do
        result = test_c4('aabbccdq', 9, nil, 6)
        expect(result).to declare_win_for 1
    end

    it 'checks only 7 columns on null column parameter' do
        result = test_c4('hq', 9, nil, 6)
        expect(result).to invalid_input invalidColumn
    end

    it 'checks that only 6 rows are present when null column parameter is present' do
        result = test_c4('aaaaaaaq', 9, nil, 6)
        expect(result).to invalid_input fullColumn
    end

    it 'checks that default board loaded on null win parameter' do
        result = test_c4('aabbccdq', 12, 9, nil)
        expect(result).to declare_win_for 1
    end

    it 'check  that only 7 columns on null win parameter' do
        result = test_c4('hq', 12, 9, nil)
        expect(result).to invalid_input invalidColumn
    end

    it 'checks only 6 rows when null win parameter input' do
        result = test_c4('aaaaaaaq', 12, 9, nil)
        expect(result).to invalid_input fullColumn
    end

    it 'checks default loadout if no input present for board size' do
        result = test_c4('aabbccdq', nil, nil, 9)
        expect(result).to declare_win_for 1
    end

    it 'checks only 7 columns present with no board parameters' do
        result = test_c4('hq', nil, nil, 9)
        expect(result).to invalid_input invalidColumn
    end

    it 'checks only 6 rows when no board params present' do
        result = test_c4('aaaaaaaq', nil, nil, 9)
        expect(result).to invalid_input fullColumn
    end

end


##How does this error input work? nvm. Got it


##So invalid_input takes an input parameter and that's what was causing the issue apparently
describe 'Generic invalid input things... let\'s see what happens here' do

    it 'detects invalid input - letter outside of range' do
        result = test_c4('abcdmq')
        expect(result).to invalid_input invalidColumn
    end

    it 'detects invalid input: column found to be full' do
        result = test_c4('aaaaaaaq')
        expect(result).to invalid_input fullColumn
    end
end

=begin

Cody's methods. There were some issues that I thought warranted a top-down re-write. But I think  I've found most of them so a
good chunk of cody's testing methods should be usable now

=end

describe 'Cody\'s C4 standard board-sized methods or something' do

    it 'detects P1 winning horizontally in row 0' do
        # Notice that the game should end before the last 'q' input is consumed
        result = test_c4('aabbccdq')
        expect(result).to declare_win_for 1
    end

    it 'detects p1 winning vertically in column A' do
        result = test_c4('ababacaq')
        expect(result).to declare_win_for 1
    end

    it 'detects p1 winning diagonally in column A-D' do
        result = test_c4('abbccdcdcddq')
        expect(result).to declare_win_for 1
    end

    it 'detects P2 winning horizontally in row 0' do
        result = test_c4('eaebecadq')
        expect(result).to declare_win_for 2
    end

    it 'detects p2 winning vertically in column A' do
        result = test_c4('bababacaq')
        expect(result).to declare_win_for 2
    end

    # zk Remember to test both forward and backward diagonals.
    it 'detects p2 winning diagonally in column A-D' do
        result = test_c4('bacbccddddq')
        expect(result).to declare_win_for 2
    end

    it 'detects p1 winning top left diagonal' do
        result = test_c4('aaaabaabbbbccccddedq')
        expect(result).to declare_win_for 1
    end

    it 'detects p2 winning top left diagonal' do
        result = test_c4('aaaaaabbbbcbccgcfdddq')
        expect(result).to declare_win_for 2
    end

    it 'detects p1 winning horizontally, with multiple areas to choose ' do
        #Basically there's multiple branches of connecting 1s, ensuring the 4 is checked as well
        result = test_c4('dadbdcaabbccqq')
        expect(result).to declare_win_for 1
    end

    it 'detects p2 winning horizontally, with multiple areas to choose ' do
        result = test_c4('adbdcddadbacqq')
        expect(result).to declare_win_for 2
    end

    it 'detects draw' do
        result = test_c4('aaaaaabbbbbbcccccceeeeeefddddddfffffggggggq')
        #expect(result).to declare_win_for -1
        expect(result).to be_abandoned
    end
end

describe 'Cody\'s Connect 4 Alternates' do

    it 'detects P1 winning horizontally in row 0, small win' do
        result = test_c4('aabbcq', 5, 4, 3)
        expect(result).to declare_win_for 1
    end

    it 'detects P2 winning horizontally in row 0, small win' do
        result = test_c4('daabbcq', 5, 4, 3)
        expect(result).to declare_win_for 2
    end

    it 'detects P1 winning vertically in column A, small win' do
        result = test_c4('ababaq', 5, 4, 3)
        expect(result).to declare_win_for 1
    end

    it 'detects P2 winning vertically in column A, small win' do
        result = test_c4('badadaq', 5, 4, 3)
        expect(result).to declare_win_for 2
    end

    it 'detects P1 winning diagonally in column A-C, small win, bottom to top' do
        result = test_c4('abbbcccq', 5, 5, 3)
        expect(result).to declare_win_for 1
    end

    it 'detects P2 winning diagonally in column A-C, small win, bottom to top' do
        result = test_c4('fabbbcccq', 6, 6, 3)
        expect(result).to declare_win_for 2
    end

    it 'detects P1 winning diagonally in column A-C, small win, top to bottom' do
        result = test_c4('aaabbbcq', 6,7,3)
        expect(result).to declare_win_for 1
    end

    it 'detects player 1 winning horizontally on a big board' do
        result = test_c4('aabbccdaeeffgghaq', 9, 9, 7)
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning horizontally on a big board' do
        result = test_c4('iaabbccddeeffgq', 9, 9, 7)
        expect(result).to declare_win_for 2
    end

    it 'detects player 1 winning vertically on a tall board' do
        result = test_c4('abababacadadq', 8, 9, 6)
        expect(result).to declare_win_for 1
    end

    it 'detects player 2 winning vertically on a tall board' do
        result = test_c4('babababadadadadaq', 8, 9, 6)
        expect(result).to declare_win_for 2
    end

    it 'quits before declaring a winner in column 0' do
        result = test_c4('iaabbccddeeffq', 9, 9, 7)
        expect(result).to be_abandoned
    end

    it 'detects draw small board' do
        result = test_c4('abcdabcddcbadcba', 4, 4, 3)
        #expect(result).to declare_win_for -1\
        expect(result).to be_abandoned
    end

    #it 'detects draw small board but with quit instead of declare_win_for -1' do
        #result = test_c4('abcdabcddcbadcba', 4, 4, 3)
        #expect(result).to be_abandoned
    #end

    it 'detects draw big board' do
        result = test_c4('aaaaaaaabbbbbbbbccccccccddddddddeeeeeeeeffffffffhgggggggghhhhhhhq', 8, 8, 7)
        #expect(result).to declare_win_for -1
        expect(result).to be_abandoned
    end

end

describe 'Cody\'s invalid inputs' do
   it 'invalid input on entering a number' do
        result = test_c4('aba6q', 7, 7, 4)
        expect(result).to invalid_input invalidColumn
    end

    it 'invalid input on entering a column too far' do
        result = test_c4('abagq', 5, 6, 4)
        expect(result).to invalid_input invalidColumn
    end

    ##Made some slight changes to this guy
    it 'invalid input on entering a row too high' do
        result = test_c4('aaaaaaaq', 6, 7, 4)
        expect(result).to invalid_input fullColumn
    end

    it 'invalid input on row parameter' do
        result = test_c4('hq', 'a', 4, 4)
        expect(result).to invalid_input
        #There shouldn't be an input at all on the row parameter though. Only a column should be
        #Selected and then the piece should "fall" to the lowest available point in the column.
    end

    it 'invalid input on column parameter' do
        result = test_c4('jq', 3, 'z', 4)
        expect(result).to invalid_input
    end

    #it 'tries to see what\'s going on with the endline' do
        #result = test_c4('abq')
        #expect(result).to declare_win_for 1
    #end
end

#So I think we figured out what we needed to here. No q leads to that 137 error code. I don't think there was any issue with
# Goodbye but we changed it anyways

#describe 'Deliberate failures: tests we used to see what\'s causing the errors to trigger' do

    #it 'we want to trigger goodby here. So let\'s see what happens if we don\'t' do

        #result = test_c4('aabbcc')
        #expect(result).to declare_win_for 1
    #end

#end


