#zk names

require 'spec_helper'
# [Check Tests]

describe 'C4 standard board size' do
    it 'detects P1 winning horizontally in row 0' do
        # Notice that the game should end before the last 'q' input is consumed
        result = test_c4('aabbccdq')
        expect(result).to declare_win_for 1
    end
    
    it 'detects p1 winning vertically in column A' do
        result = test_c4('ababacaq')
        expect(result).to declare_win_for 1
    end
    
    it 'detects p1 winning diagonally in column A-D' do
        result = test_c4('abbccdcdcdq')
        expect(result).to declare_win_for 1
    end
    
    it 'detects P2 winning horizontally in row 0' do
        result = test_c4('eaebecadq')
        expect(result).to declare_win_for 2
    end
    
    it 'detects p2 winning vertically in column A' do
        result = test_c4('bababacaq')
        expect(result).to declare_win_for 2
    end
    
    # zk Remember to test both forward and backward diagonals.
    it 'detects p2 winning diagonally in column A-D' do
        result = test_c4('bacbccddddq')
        expect(result).to declare_win_for 2
    end
    
    it 'detects p1 winning top left diagonal' do
        result = test_c4('aaaabaabbbbccccddedq')
        expect(result).to declare_win_for 1
    end
    
    it 'detects p2 winning top left diagonal' do
        result = test_c4('aaaaaabbbbcbccgcfdddq')
        expect(result).to declare_win_for 2
    end

    # zk  Remember:  You aren't just testing the quit function.  
    # You are verifying that the game does *not* detect a win when it shouldn't.
    # So you will want several like this.  Think about various game states immediately
    # before quitting that buggy code might detect as a win.
    it 'quits before declaring a winner in column 0' do
        result = test_c4('abababq')
        expect(result).to be_abandoned
    end
    
    # zk This is fine if it works for you.  Remember, however, that the 
    # c4 program won't exit when given invalid input.  The fact that the game is still
    # running may mess with the tests.
    #
    # Another approach is to finish the game after the invalid input (e.g., aab6bccd)
    # and verify a win.
    it 'invalid input on entering a number' do
        result = test_c4('aba6q')
        expect(result).to invalid_input
    end
    
    it 'invalid input on entering a column too far' do
        result = test_c4('abahq')
        expect(result).to invalid_input
    end
    
    it 'invalid input on entering a row too high' do
        result = test_c4('aaaaaaaq')
        expect(result).to invalid_input
    end
    
    it 'detects p1 winning horizontally, with multiple areas to choose ' do
        #Basically there's multiple branches of connecting 1s, ensuring the 4 is checked as well
        result = test_c4('dadbdcaabbccqq')
        expect(result).to declare_win_for 1
    end
    
    it 'detects p2 winning horizontally, with multiple areas to choose ' do
        result = test_c4('adbdcddadbacqq')
        expect(result).to declare_win_for 2
    end
    
    it 'detects draw' do
        result = test_c4('aaaaaabbbbbbcccccceeeeeefddddddfffffggggggq')
        expect(result).to declare_win_for 0
    end
    
    it 'detects automatically choosing default, row' do
        #No input provided for rows defaults to 6,7,4
        result = test_c4('aabbccddq',nil , 8, 4)
        expect(result).to declare_win_for 1
    end
    
    it 'detects automatically choosing default, column' do
        #No input provided for columns defaults to 6,7,4
        result = test_c4('aabbccddq', 2,nil , 4)
        expect(result).to declare_win_for 1
    end
    
    it 'detects automatically choosing default, win' do
        #No input provided for wins defaults to 6,7,4
        result = test_c4('aabbccddq', 2, 4 ,nil)
        expect(result).to declare_win_for 1
    end
end


describe 'Connect 4 alternate' do
    
    it 'detects P1 winning horizontally in row 0, small win' do
        result = test_c4('aabq', 5, 4, 2)
        expect(result).to declare_win_for 1
    end
    
    it 'detects P2 winning horizontally in row 0, small win' do
        result = test_c4('daabq', 5, 4, 2)
        expect(result).to declare_win_for 2
    end
    
    it 'detects P1 winning vertically in column A, small win' do
        result = test_c4('abaq', 5, 4, 2)
        expect(result).to declare_win_for 1
    end
    
    it 'detects P2 winning vertically in column A, small win' do
        result = test_c4('badaq', 5, 4, 2)
        expect(result).to declare_win_for 2
    end
    
    it 'detects P1 winning diagonally in column A-C, small win, bottom to top' do
        result = test_c4('abbcdccq', 5, 5, 3)
        expect(result).to declare_win_for 1
    end
    
    it 'detects P2 winning diagonally in column A-C, small win, bottom to top' do
        result = test_c4('bacbccq', 6, 6, 3)
        expect(result).to declare_win_for 2
    end

    it 'detects P1 winning diagonally in column A-C, small win, top to bottom' do
        result = test_c4('abadbdc', 6,7,3)
        expect(result).to declare_win_for 1
    end
    
    it 'detects player 1 winning horizontally on a big board' do
        result = test_c4('aabbccdaeeffgghaq', 3, 9, 7)
        expect(result).to declare_win_for 1
    end
    
    it 'detects player 2 winning horizontally on a big board' do
        result = test_c4('iaabbccddeeffgq', 3, 9, 7)
        expect(result).to declare_win_for 2
    end
    
    it 'detects player 1 winning vertically on a tall board' do
        result = test_c4('abababacadadq', 8, 4, 6)
        expect(result).to declare_win_for 1
    end
    
    it 'detects player 2 winning vertically on a tall board' do
        result = test_c4('babababadadadadaq', 8, 4, 6)
        expect(result).to declare_win_for 2
    end

    it 'quits before declaring a winner in column 0' do
        result = test_c4('iaabbccddeeffq', 3, 9, 7)
        expect(result).to be_abandoned
    end
    
    it 'invalid input on entering a number' do
        result = test_c4('aba6q', 7, 7, 4)
        expect(result).to invalid_input
    end
    
    it 'invalid input on entering a column too far' do
        result = test_c4('abagq', 5, 6, 4)
        expect(result).to invalid_input
    end
    
    ##Made some slight changes to this guy
    it 'invalid input on entering a row too high' do
        result = test_c4('aaaaaaaq', 6, 7, 4)
        expect(result).to invalid_input
    end
    
    it 'detects draw small board' do
        result = test_c4('aaabbbdcccddq', 3, 4, 3)
        expect(result).to declare_win_for 0
    end
    
    it 'detects draw big board' do
        result = test_c4('aaaaaaaabbbbbbbbccccccccddddddddeeeeeeeeffffffffhgggggggghhhhhhhq', 8, 8, 8)
        expect(result).to declare_win_for 0
    end
    
    it 'invalid input on row parameter' do
        result = test_c4('hq', 'a', 4, 4)
        expect(result).to invalid_input
        #There shouldn't be an input at all on the row parameter though. Only a column should be
        #Selected and then the piece should "fall" to the lowest available point in the column.
    end
    
    it 'invalid input on column parameter' do
        result = test_c4('jq', 3, 'z', 4)
        expect(result).to invalid_input
    end
    
    ##Pretty sure it's supposed to exit on win.
    #it 'invalid input on win parameter' do
        #result = test_c4('', 3, 5, b)
        #expect(result).to invalid_input
    #end
end
