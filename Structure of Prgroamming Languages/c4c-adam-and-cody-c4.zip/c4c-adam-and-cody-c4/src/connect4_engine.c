/* 
   zzNAMEzz 
   Adam Winebarger & Cody Delano

   Place all your Connect4 functions here --- except for main.
   main() needs to go in its own separate .c file.3
*/

#include "connect4.h"

#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
//static char *board; //Of course I suppose this is an option too. Nope. Let's not do this

//static vars
static char *columnLetters = "ABCDEFGHIJKLMNOP\0";

//non-"static" instance variables
int row, col, winCondition;

char *board, //our board instance variable. Might make this static in the future
*columnDisplay; //and one to show the number of columns to be displayed.

bool victory = false, draw = false;
char currentPlayersTurn = '1';


//predefined functions so that we don't have to worry about positioning
char *substring(const char *src, int m, int n); //supplementary functions to ease the work we have to do
int indexOf(char *str, char chr);
bool isValidNumber(const char *str);
int str2Int(const char *str);
int sixteenMax(int input);
//char toUpper(char c);
bool isValidChar(char c);
int getColumnNumber(char c);

bool checkValidParameters(int argc, char* argv[]); //functions to check/define parameters
void setDefaultBoardParameters();

void generateBoard(); //board generation and move-making functions
void showBoard();
void playGame();
void newTurn();
void playerPrompt();
int dropChip(char colDrop); //making this an int will make it easier to get the row it landed in
bool validColumnSelected(char col);

bool x_in_a_row(int currentRow, int currentColumn); //win condition
bool checkDraw();

//teardown
void endGame();

//This will be like a constructor of sorts for a class. Once argc and argv are passed
void newGame2(int argc, char *argv[]) {

    //printf("Arrived at newGame2\n");
//     bool checks[] = {isValidNumber("2"), isValidNumber("23"), isValidNumber("645"), isValidNumber("a"),
//         isValidNumber("-1"), isValidNumber("-"), isValidNumber("ab"), isValidNumber("xyz")
//     }; //looks like our valid number checker works
//
//     for (int i = 0; i < 8; i++) {
//         printf("%d\n", checks[i]);
//     }

//looks like our arguments parsing worked.
//     int separator = indexOf(argv[1], 'x');
//     char *rowSTR = substring(argv[1], 0, separator), *colStr = substring(argv[1], separator+1, strlen(argv[1]));
//     printf("%d\n%d\n%d\n", isValidNumber(rowSTR), isValidNumber(colStr), isValidNumber(argv[2]));


    if (checkValidParameters(argc, argv) == false)
        setDefaultBoardParameters();


    //printf("%d\n%d\n%d\n", row, col, winCondition);

    generateBoard();
    showBoard();

    //stuff will happen in between these two functions but it's just for testing now
    //stuff ended up not happening between these two functions

    playGame();
    endGame();

}

//probably makes sense to do most of the parameter-checking leg-work here
bool checkValidParameters(int argc, char* argv[])
{
    //Not sure if merging these two catchments was the right call. But this provides catchment for if the program has been
    //executed with too many or too few arguments and also kicks back if the "axb" arguemnent is missing an x (signifying only one
    //value in that parameter)
    if (argc != 3)
        return false;

    int separator = indexOf(argv[1], 'x');

    if (separator == -1)
        return false;

    //our substring method is basically functionally the same as a java substring method.
    //so with the parameters set the way they are using
    char *rowSTR = substring(argv[1], 0, separator), *colStr = substring(argv[1], separator+1, strlen(argv[1]));


    //now that we've determined that argv 1 and 2 can be broken into 3 parameters, we need to check that all 3 are numbers
    //and kickback to default parameters if one or more of them isn't
    if (!isValidNumber(rowSTR) || !isValidNumber(colStr) || !isValidNumber(argv[2])) {
        //determines that all aruments presented are numbers
        free(rowSTR);
        free(colStr);
        return false;
    }




    //once we know that all 3 of our params are numbers, we can use our str2Int method without worry of
    //undefined behavior
    int rowD = sixteenMax(str2Int(rowSTR)),
    colD = sixteenMax(str2Int(colStr)),
    winD = str2Int(argv[2]); //and we can also cap row and col at 16 here

    free(rowSTR);
    free(colStr);

    //May as well because it wouldn't be much fun with less than a 4x4 board or less than 3 in a row
    //... frankly, I think 4 should be the min for the win condition so that might change in a bit
    if (rowD < 1 || colD < 1 || winD < 1)
        return false;

    //this portion will probably need to be re-worked a bit, but for now, we're going to kick back false
    //if win is greater than or equal to row OR column

    //Though I really think this should be in here, I think it's causing problems with the instuctor tests
    //so commented out is the next best thing, I guess.
//     if (winD > rowD || winD > colD)
//         return false;

    //Slightly modified version of the catchment
    if (winD > rowD && winD > colD)
        return false;


    //Put any additional failure parameters we think of here

    //but barring any failure, the only thing to do is set the parameters and return true;
    row = rowD, col = colD, winCondition = winD;
    return true;

}


void setDefaultBoardParameters()
{
    row = 6, col = 7, winCondition = 4;
}


//since row, col, and winCondition are instance variables and they'll be set
void generateBoard()
{
    board = malloc((row * col + 1)* sizeof(char));

    for (int i = 0; i < row * col; i++)
        board[i] = '.';

    board[row*col] = '\0'; //always good practice to end things with a null-terminating character

    //may as well handle column generation here too.
    columnDisplay = malloc(col * sizeof(char));

    for (int i = 0; i < col; i++)
        columnDisplay[i] = columnLetters[i];
}

void showBoard()
{
    for (int i = 0; i < col; i++)
        printf("%c ", columnDisplay[i]);
    printf("\n");

    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            printf("%c ", board[i * col + j]);
        }
        printf("\n");
    }
}

//This is where the actual game will take place.
//Basically, we can use a simple while loop that continues to iterate as long as victory is equal to false, then at the end of each
//loop have victory be set to the output of x_in_a_row.
//
//Also would be beneficial to have a break condition for a draw method -> make that a boolean as well and have it just break from
//the loop. I suppose recursion might make this look cleaner. But let's go with a while loop for now
//could also do something like: victory = (playerVictory() || draw())
void playGame()
{
    char playerInput; //might be worthwhile to make this a char array and then only pass the first value to our drop method
    int col2Drop, rowLanded = -1;

    while (!victory && !draw) {

        //showBoard();
        playerPrompt();
        scanf(" %c", &playerInput);
        //printf("\n");

        if (playerInput == 'q' || playerInput == 'Q' ) {
            printf("Goodbye.\n");
            return;
        }


        col2Drop = getColumnNumber(toupper(playerInput));


        if (isValidChar(playerInput) == true && col2Drop != -1) {

            //printf("%d\n", getColumnNumber(toupper(playerInput)));
            rowLanded = dropChip(col2Drop);
            //printf("This triggered\n");
            if (rowLanded != -1) {
                if (x_in_a_row(rowLanded, col2Drop)) {
                    showBoard();
                    printf("Congratulations, Player %c. You win.\n", currentPlayersTurn);
                    victory = true; //with this in mind victory might not even be necessary
                    return;
                }
                newTurn();
            }
        }

        showBoard();

        if (checkDraw()) {
            printf("Board full up. Game ends in a draw.\nGoodbye.\n");
            draw = true;
//                     while (playerInput != 'q')
//                         scanf( "%c", &playerInput);
//                     printf("Goodbye.\n");
            return;
        }


    }
}


//x_in_a_row
bool x_in_a_row(int currentRow, int currentColumn) {
    /*
     *not sure if we should pass the pointer to the board as an input parameter here or just have it be an instance variable.
     * But we should also have the location of the most recently input peice as input parameters (Either just the column or the
     * actual location of the most recent piece... not sure yet). But from there, all we really have to do is check and see if
     * the pieces to the left and right match (horizontal), upper and lower match (vertical), and diagonals match (ulbr and urbl),
     * incrementing for every match they find and breaking from those loops when they either hit the bounds or find a non-matching or
     * empty piece.
     */

    //with the way we sest up our row and column detection, this will be the easiest catchment over here to not even bother
    // and/or not run into undefined behavior in the event that one of these is invalid
    if (currentRow == -1 || currentColumn == -1)
        return false;


    int horizontalRow = 1, vertRow = 1, tr2blRow = 1, tl2brRow = 1;
    int i; //we're going to be reusing these guys a lot
    int currentPieceLoc = col*currentRow + currentColumn;
    printf("%d\n", currentPieceLoc);
    char currentPiece = board[currentPieceLoc];

    /*
     * So the way this should work is we look at the current positioning of the most recently dropped piece and basically decrement
     * to the left until we see either 0 or some number i where i % col = 0 going to the left, col - 1 to the right, OR until we have a mismatch between characters and
     * that will tell us how many horizontal matches we have in a row. Then we can do the same for vertical and the same
     * for diagonals to see if we have any matches of 4 pieces.
     */

    //First we check the left.. we've got it backwards. We want to check the 0 spot so we want to go until i & col = col - 1
    //basically we're decrementing to the left from the current position until we either hit a mismatch or hit the left-most bound
    for (i = currentPieceLoc-1; i >= 0 && i % col != col - 1; i--) {
        if (board[i] == currentPiece)
            horizontalRow++;
        else
            break;
    }

    //now we go to the right... +1 is added to the mix to ensure that
    //this one is the same as above except it increments until mismatch or rightmost bount
    for (i = currentPieceLoc+1; i % col != 0; i++) {
        if (board[i] == currentPiece)
            horizontalRow++;
        else
            break;
    }

    //printf("horizontalRow: %d\n", horizontalRow);
    //now we tally to see if horizontalRow met the win condition... because why bother going further if it did?
    if (horizontalRow >= winCondition)
        return true;    //welp. looks like the horizontal method works


    //Time for the vertical
    //This one is a bit trickier. Basically we're incrementing by col until we hit the upper bound or mismatch
    for (i = currentPieceLoc-col; i >= 0; i -= col) {
        if (board[i] == currentPiece)
            vertRow++;
        else
            break;
    }

    //figured out the issue. Was calling the wrong variable. We're good now, vert works
    //This one was the most difficult so far. But it basically increments by col until it hits the lower bound at row*col
    for (i = currentPieceLoc + col; i < row * col; i += col) {
        if (board[i] == currentPiece)
            vertRow++;
        else
            break;
    }

    //printf("Vert row: %d\n", vertRow);
    //printf("%d\n", vertRow);
    if (vertRow >= winCondition)
        return true;

    //Now time for diagonals. Let's start with
    //I guess i can be uppers and j can be across... maybe
    //actually we might be able to do a single variable for loop here

    //first we will do from top-right to bottom left

    //from current position, up and to the right. So that's increment by 1, decrement by col
    for (i = currentPieceLoc + 1 - col; i >= 0 && i % col != 0; i = i + 1 - col) {
        if (board[i] == currentPiece)
            tr2blRow++;
        else
            break;
    }

    //from current position, down and to the left: so we decrement by 1 and increment by col
    //starting from currentPieceLoc + col - 1 to avoid counting currentPieceLoc twice
    for (i = currentPieceLoc + col - 1; i < row * col && i % col != col - 1; i = i + col - 1) {
        if (board[i] == currentPiece)
            tr2blRow++;
        else
            break;
    }

    //printf("tr2blRow: %d\n", tr2blRow);

    //now we check topRight to Bottom left diagonals
    if (tr2blRow >= winCondition)
        return true;

    //Now we can to top-left to bottom right

    //starting from current position, going up and to the left - so that's decrement by 1, decrement by col
    for (i = currentPieceLoc - col - 1; i >= 0 && i % col != col - 1; i = (i - col) - 1) {
        if (board[i] == currentPiece)
            tl2brRow++;
        else
            break;
    }

    //now we go from current position + 1 + col and we're checking down & to the right.
    //So that would be increment by 1 and increment by col
    for (i = currentPieceLoc + 1 + col; i < col * row && i % col != 0; i += col + 1) {
        if (board[i] == currentPiece)
            tl2brRow++;
        else
            break;
    }

    //printf("tl2brRow: %d\n", tl2brRow);

    //now we check this last fucker
    if (tl2brRow >= winCondition)
        return true;

    return false;

}

// You don't have to use this.  It's just here as a demo.
//Basically just trying to say that this function is deprecated going forward... still left it in though
int x_in_a_rowD(int x, int length, int array[]) {

    //remember x in a row will have to host all of the logical bits for win-condition checking in this one function

    // This isn't correct.  It's just for demonstration purposes.
    if (length >=2 && array[0] == array[1]) {
        return array[0];
    } else {
        return -1;
    };
}

bool checkDraw() {

    //this should basically return false as long as there is at least one piece on the board still unoccupied
    for (int i = 0; i < row * col; i++)
        if (board[i] == '.')
            return false;   //since we don't care about the formatting of the board and just want to find an unnocupied slot, this will suffice

    return true;
}

//This porbably didn't need its own function. But I thought I was going to put more in here.
void playerPrompt()
{
    printf("Player %c's turn: ", currentPlayersTurn);
}

//Since we've got to get it to the "lowest" point in the array, this is what I came up with
int dropChip(char colDrop)
{

    //checked the math and this works. Basically, it increments by column and adds an offset based on the user Selected colum.
    //But it's basically a for loop starting at the highest possible row and decrementing until it finds the first empty
    //cell (or the first one with '.' in it)

    //printf("%d\n", colDrop);
    for (int i = row-1; i >= 0; i--) {
        //printf("%d\n", i);
        if (board[colDrop + col * i] == '.') {
            board[colDrop + col * i] = currentPlayersTurn;
            return i;
        }
    }

    //catchment for if the column is full/the game couldn't find an empty space in that column
    printf("column found to be full up. Please choose another\n");
    return -1;
}



void endGame()
{
    //printf("Goodbye\n");
    free(board);
    free(columnDisplay);

}

//newGame function that we didn't use
// void newGame(int row, int col, int winCondition) {
//     //printf("Testing new Game\n"); //passes
//
// }

/*General-purpose/supplementary functions to make our lives easier*/



int indexOf(char* str, char chr)
{
    char *pos = strchr(str, chr);
    return pos ? pos - str : -1; //looks for the character in arg1, returns -1 if it fails to find it; as any good indexOf method should
}

//extracts characters in src between positions m and n (not including n)
char *substring(const char *src, int m, int n) {
    //for the first number, use 0 and indexOf(argv[1], 'x')
    //for the second, use indexOf(argv[1], 'x') + 1 and the length of argv[1]

    //first we need length of destination substring
    int len = n - m;

    //allocate (len + 1) chars for destination string (+1 for null-terminating char)
    char *dest = (char*) malloc(sizeof(char) * (len + 1));

    //extract chars between m and n indices from source and copy them to destination string
    for (int i = m; i < n && *(src+i); i++) {
        *dest = *(src+i);
        dest++;
    }

    //add null-terminating character to the end of destination string
    *dest = '\0';

    //return destination string
    return dest - len;
}

//It just occured to me this can be really simply made since we only want positive whole numers
bool isValidNumber(const char *str) {
    for (int i = 0; i < strlen(str); i++)
        if (isdigit(str[i]) == 0)
            return false;
    return true;

}

//Since we'll only be using this after checking that our arguments are valid number, and since we only want positive
//whole numbers, atoi should be fine here. Though it may lead to some undefined behavior if used for more robust operations
int str2Int(const char* str)
{
    return atoi(str);
}


//I feel like this is pretty self-explanatory, but we'll use this to cap rows and cols at 16
//although we may have it defer to the default parameters instead in which case this won't even get used
int sixteenMax(int input)
{
    if (input >= 16)
        return 16;
    return input;
}

// char toUpper(char c)
// {
//     if (c >= 'a' && c <= 'z')
//         return c - 'a' + 'A';
//     return c;
// }

bool isValidChar(char c)
{
    if (c >= 'a' && c <= 'z')
        return true;
    if (c >= 'A' && c <= 'Z')
        return true;
    return false;
}

//converts the char input from the player into a usable column number for calcs in where the peice "can" go
int getColumnNumber(char c)
{
    for (int i = 0; i < col; i++) {
        if (c == columnDisplay[i])
            return i;
    }

    printf("Invalid column selected\n");
    return -1;
}

void newTurn()
{
    if (currentPlayersTurn == '1')
        currentPlayersTurn = '2';
    else
        currentPlayersTurn = '1';
}

// void debugPlayGame(char c)
// {
//     char playerInput; //might be worthwhile to make this a char array and then only pass the first value to our drop method
//     int col2Drop, rowLanded = -1;
//
//     //while (!victory && !draw) {
//
//         //showBoard();
//         playerPrompt();
//         playerInput = c;
//         printf("\n");
//
//         if (playerInput == 'q' ) {
//             printf("Goodbye.\n");
//             return;
//         }
//
//
//         col2Drop = getColumnNumber(toupper(playerInput));
//
//
//         if (isValidChar(playerInput) == true && col2Drop != -1) {
//
//             //printf("%d\n", getColumnNumber(toupper(playerInput)));
//             rowLanded = dropChip(col2Drop);
//             //printf("This triggered\n");
//             if (rowLanded != -1) {
//                 if (x_in_a_row(rowLanded, col2Drop)) {
//                     showBoard();
//                     printf("Congratulations, Player %c. You win.\n", currentPlayersTurn);
//                     victory = true; //with this in mind victory might not even be necessary
//                     return;
//                 }
//                 newTurn();
//             }
//         }
//
//         //Probably not going to use this guy. But still
// //         if (rowLanded == -1)
// //             printf("Column is full up. Please pick another.\n");
//
//
//         //victory = true;
//         //k++;
//         showBoard();
//         //printf("%c\n", board[col*rowLanded + col2Drop]);
// //         if (x_in_a_row(rowLanded, col2Drop)) {
// //             printf("Player %c Wins!\n", currentPlayersTurn);
// //             victory = true;
// //         }
//
//         if (checkDraw()) {
//                     printf("Board full up. Game ends in a draw\n");
//                     draw = true;
//         }
//     //}
// }
//
// /* DEBUG Methods used to check functionality*/
// void debugNewGame(int argc, char *argv[]) {
//
// //     looks like our arguments parsing worked.
// //     int separator = indexOf(argv[1], 'x');
// //     char *rowSTR = substring(argv[1], 0, separator), *colStr = substring(argv[1], separator+1, strlen(argv[1]));
// //     printf("%d\n%d\n%d\n", isValidNumber(rowSTR), isValidNumber(colStr), isValidNumber(argv[2]));
//
//
//     if (checkValidParameters(argc, argv) == false)
//         setDefaultBoardParameters();
//
//
//     //printf("%d\n%d\n%d\n", row, col, winCondition);
//
//     generateBoard();
//     //showBoard();
//
//     //stuff will happen in between these two functions but it's just for testing now
//     //stuff ended up not happening between these two functions
//
//     //playGame();
//     endGame();
//
// }

