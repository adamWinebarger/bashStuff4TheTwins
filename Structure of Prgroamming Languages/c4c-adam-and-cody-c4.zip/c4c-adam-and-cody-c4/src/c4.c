/* 
   zzNAMEzz 
   Adam Winebarger & Cody Delano

   Place your Connect4's main() function here.
   Anything that you want unit tested must go in a separate file.
*/
# include <stdio.h>
#include <stdlib.h>

#include "connect4.h"

int main(int argc, char* argv[]) {

    //int row, col, winCondition;

//     for (int i = 1; i < argc; i++)
//         printf("%s ", argv[i]);

    //args are separated by a space, 0 is the execution, 1 will be row*col, 2 will be winConditon.
    //Anything more or less than that will be a bad number of args and will trigger a default.
//     if (argc != 3)
//         row = 6, col = 7, winCondition = 4;

    //char rowC[5], colC[5];

    //newGame(row, col, winCondition); //new game may need to be passed input args

    newGame2(argc, argv);
    //free(argv);
    return 0;
}
