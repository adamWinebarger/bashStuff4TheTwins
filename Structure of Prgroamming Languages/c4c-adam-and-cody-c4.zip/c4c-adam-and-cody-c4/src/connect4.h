#ifndef CONNECT4_H
#define CONNECT4_H

// Declare your helper functions here.
#include <stdio.h>


// You don't have to use this.  It's just here as a demo.
int x_in_a_rowD(int x, int length, int array[]);

void newGame(int row, int col, int winCondition);
void newGame2(int argc, char *argv[]);

#endif
